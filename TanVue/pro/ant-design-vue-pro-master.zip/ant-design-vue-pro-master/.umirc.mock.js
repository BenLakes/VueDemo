module.exports = {
  ...require("./mock/api"),
  ...require("./mock/chart"),
  ...require("./mock/geographic"),
  ...require("./mock/notices"),
  ...require("./mock/profile"),
  ...require("./mock/rule"),
  ...require("./mock/user")
};
