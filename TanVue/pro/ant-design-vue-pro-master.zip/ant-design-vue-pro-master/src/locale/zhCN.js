export default {
  "app.dashboard.analysis.timeLabel": "时间",
  "component.globalHeader.notification": "通知",
  "component.globalHeader.notification.empty": "您已查看所有通知",
  "component.globalHeader.message": "消息",
  "component.globalHeader.message.empty": "您已读完所有消息",
  "component.globalHeader.event": "待办",
  "component.globalHeader.event.empty": "您已完成所有待办",
  "component.noticeIcon.clear": "清空",
  "component.noticeIcon.cleared": "清空了",
  "component.noticeIcon.empty": "暂无数据",
  "component.noticeIcon.view-more": "查看更多"
};
