export default {
  "app.dashboard.analysis.timeLabel": "Time",
  "component.globalHeader.notification": "Notification",
  "component.globalHeader.notification.empty":
    "You have viewed all notifications.",
  "component.globalHeader.message": "Message",
  "component.globalHeader.message.empty": "You have viewed all messages.",
  "component.globalHeader.event": "Event",
  "component.globalHeader.event.empty": "You have viewed all events",
  "component.noticeIcon.clear": "Clear",
  "component.noticeIcon.cleared": "Cleared",
  "component.noticeIcon.empty": "No notifications",
  "component.noticeIcon.view-more": "View more"
};
