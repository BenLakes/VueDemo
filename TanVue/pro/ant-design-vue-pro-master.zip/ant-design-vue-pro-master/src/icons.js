export {
  default as SettingOutline
} from "@ant-design/icons/lib/outline/SettingOutline";
export {
  default as GithubOutline
} from "@ant-design/icons/lib/outline/GithubOutline";
export {
  default as CopyrightOutline
} from "@ant-design/icons/lib/outline/CopyrightOutline";
export {
  default as CloseOutline
} from "@ant-design/icons/lib/outline/CloseOutline";
