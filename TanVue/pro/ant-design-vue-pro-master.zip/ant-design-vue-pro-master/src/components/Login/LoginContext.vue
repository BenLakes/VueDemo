<script>
import { createContext } from "vue-create-context";

const LoginContext = createContext();
export default LoginContext;
</script>
