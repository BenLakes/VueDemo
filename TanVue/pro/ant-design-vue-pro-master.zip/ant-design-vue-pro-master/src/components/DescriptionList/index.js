import DescriptionList from "./DescriptionList.vue";
import Description from "./Description.vue";

DescriptionList.Description = Description;
export default DescriptionList;
