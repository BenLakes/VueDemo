import NoticeIcon from "./NoticeIcon.vue";
import NoticeList from "./NoticeList.vue";
NoticeIcon.Tab = NoticeList;

export default NoticeIcon;
export { NoticeList };
