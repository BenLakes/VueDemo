<template>
  <div>Ant Design Vue Pro ©2019 Created by GeekTime</div>
</template>

<script>
export default {};
</script>

<style></style>
