<template>
  <div>操作成功，预计两小时到账</div>
</template>

<script>
export default {};
</script>

<style></style>
